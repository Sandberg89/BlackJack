﻿// Name: Linus Sandberg. Date: 2020-09-20. Project: Black Jack Game Assignment 1
using System;
using System.Collections.Generic;
using System.Text;

namespace LogicLayer.Enums
{
    public enum SuitType
    {
        Club,
        Diamond,
        Heart,
        Spade
    }
}
